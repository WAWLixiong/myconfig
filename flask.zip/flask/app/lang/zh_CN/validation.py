'''
@Author: hua
@Date: 2019-05-28 20:11:04
@LastEditors: hua
@LastEditTime: 2019-05-30 15:37:32
'''

validation = {
    #验证规则
    'required':{
        True:'必须',
        False: '非必须'
    },
    'type':'类型',
    'string': '字符串',
    'integer': '整形',
    'minlength': '最小长度',
    'maxlength': '最大长度',
    #验证字段
    'nickName': '昵称',
    'headImg': '头像',
    'email': '邮箱',
    'password': '密码'
}