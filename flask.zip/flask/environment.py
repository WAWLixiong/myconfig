"""
@Author: hua
@Date: 2019-12-19 09:50:25
@description:
@LastEditors  : hua
@LastEditTime : 2019-12-19 09:53:29
"""
import json
import os


def init(name: str):
    """
    初始化运行环境
    @param name: str
    return void
    """
    path = f'{os.getcwd()}/.runtime/environment.json'
    data = {"environment": name}
    with open(path, "w+") as f:
        f.write(json.dumps(data))


def read() -> dict:
    """ 读取环境变量
        return dict enviroment
    """
    with open(f'{os.getcwd()}/.runtime/environment.json', "r") as f:
        return json.loads(f.read())['environment']
